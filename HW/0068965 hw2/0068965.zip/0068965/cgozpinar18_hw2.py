# To add a new cell, type '# %%'
# To add a new markdown cell, type '# %% [markdown]'
# %% [markdown]
# # Homework
# ## Can Gözpınar 68965

# %%
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

# %% [markdown]
# ### Read in Data from csv files

# %%
#read in data from csv files
dataSetImages = np.genfromtxt("hw02_data_set_images.csv", delimiter = ",") #data 
dataSetLabels = np.genfromtxt("hw02_data_set_labels.csv", dtype = 'str') #labels
#get rid of "" around class names
dataSetLabels = np.char.strip(dataSetLabels, '"').astype(str)
dataSet = np.hstack((dataSetImages, dataSetLabels[:, None])) #321th column is label of the xi

# %% [markdown]
# ### Divide the data set

# %%
#first 25 of each class to training set
trainingDataSet = np.vstack((dataSet[dataSet[:,-1] == 'A'][0:25], dataSet[dataSet[:,-1] == 'B'][0:25], dataSet[dataSet[:,-1] == 'C'][0:25], dataSet[dataSet[:,-1] == 'D'][0:25], dataSet[dataSet[:,-1] == 'E'][0:25]))

#last 14 of each class to test set
testDataSet = np.vstack((dataSet[dataSet[:,-1] == 'A'][25:], dataSet[dataSet[:,-1] == 'B'][25:], dataSet[dataSet[:,-1] == 'C'][25:], dataSet[dataSet[:,-1] == 'D'][25:], dataSet[dataSet[:,-1] == 'E'][25:]))

# %% [markdown]
# ### Learn multiclass using Sigmoid function

# %%
# define the sigmoid function
def sigmoid(X, w, w0):
    return(1 / (1 + np.exp(-(np.matmul(X, w) + w0))))


# %%
# define the gradient functions
def gradient_W(X, y_truth, y_predicted):
    return(np.asarray([-np.sum(np.repeat((Y_truth[:,c] - Y_predicted[:,c])[:, None], X.shape[1], axis = 1) * X, axis = 0) for c in range(5)]).transpose())

def gradient_w0(Y_truth, Y_predicted):
    return(-np.sum(Y_truth - Y_predicted, axis = 0))


# %%
# set learning parameters
eta = 0.01
epsilon = 1e-3


# %%
# randomly initalize W and w0
np.random.seed(1)
W = np.random.uniform(low = -0.01, high = 0.01, size = (trainingDataSet.shape[1] - 1, 5))
w0 = np.random.uniform(low = -0.01, high = 0.01, size = (1, 5))
#print(sigmoid(trainingDataSet[:,:-1].astype(float),W,w0).shape, Y_truth.shape)


# %%
def safelog(x):
    return(np.log(x + 1e-100))#to prevent log0


# %%
# one-of-K encoding
y_truth = trainingDataSet[:,-1]
Y_truth = np.zeros((len(y_truth), 5)).astype(int)
for i in range(y_truth.shape[0]):
    if(y_truth[i] == 'A'):
        Y_truth[i, 0] = 1
    if(y_truth[i] == 'B'):
        Y_truth[i, 1] = 1
    if(y_truth[i] == 'C'):
        Y_truth[i, 2] = 1
    if(y_truth[i] == 'D'):
        Y_truth[i, 3] = 1
    if(y_truth[i] == 'E'):
        Y_truth[i, 4] = 1


# %%
# learn W and w0 using gradient descent
iteration = 1
objective_values = []
while 1:
    X = trainingDataSet[:,:-1].astype(float)
    Y_predicted = sigmoid(X,W,w0)

    objective_values = np.append(objective_values, -np.sum(Y_truth * safelog(Y_predicted)))

    W_old = W
    w0_old = w0

    W = W - eta * gradient_W(X, Y_truth, Y_predicted)
    w0 = w0 - eta * gradient_w0(Y_truth, Y_predicted)

    if np.sqrt(np.sum((w0 - w0_old))**2 + np.sum((W - W_old)**2)) < epsilon:
        break

    iteration = iteration + 1

# %% [markdown]
# ## Plot the objective function

# %%
# plot objective function during iterations
plt.figure(figsize = (10, 6))
plt.plot(range(1, iteration + 1), objective_values, "k-")
plt.xlabel("Iteration")
plt.ylabel("Error")
plt.show()

# %% [markdown]
# ## Confusion Matrix Calculations

# %%
#calculate the confusion matrix for the training data set
y_truth[ y_truth == 'A' ] = 1
y_truth[ y_truth == 'B' ] = 2
y_truth[ y_truth == 'C' ] = 3
y_truth[ y_truth == 'D' ] = 4
y_truth[ y_truth == 'E' ] = 5

y_predicted = np.argmax(Y_predicted, axis = 1) + 1
confusion_matrix = pd.crosstab(y_predicted, y_truth, rownames = ['y_pred'], colnames = ['y_truth'])
print(confusion_matrix)


# %%
#calculate the confusion matrix for the test data set
y_truth = testDataSet[:,-1]
y_truth[ y_truth == 'A' ] = 1
y_truth[ y_truth == 'B' ] = 2
y_truth[ y_truth == 'C' ] = 3
y_truth[ y_truth == 'D' ] = 4
y_truth[ y_truth == 'E' ] = 5

X = testDataSet[:,:-1].astype(float)
Y_predicted = sigmoid(X,W,w0)
y_predicted = np.argmax(Y_predicted, axis = 1) + 1
confusion_matrix = pd.crosstab(y_predicted, y_truth, rownames = ['y_pred'], colnames = ['y_truth'])
print(confusion_matrix)


