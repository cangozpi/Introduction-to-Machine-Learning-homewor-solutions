# To add a new cell, type '# %%'
# To add a new markdown cell, type '# %% [markdown]'
# %% [markdown]
# ## ENGR421 
# ## HW #06
# ### Can Gözpınar 68965

# %%
import matplotlib.pyplot as plt
import numpy as np
import scipy.spatial as spa
from scipy.stats import multivariate_normal

# %% [markdown]
# ### Generate Random Data Points

# %%
np.random.seed(421) #to get the same random variables at each run
# generate random samples
X1 = np.random.multivariate_normal(np.asarray([+2.5, +2.5]), np.matrix([[0.8, -0.6], [-0.6, 0.8]]), 50)
X2 = np.random.multivariate_normal(np.asarray([-2.5, +2.5]), np.matrix([[0.8, 0.6], [0.6, 0.8]]), 50)
X3 = np.random.multivariate_normal(np.asarray([-2.5, -2.5]), np.matrix([[0.8, -0.6], [-0.6, 0.8]]), 50)
X4 = np.random.multivariate_normal(np.asarray([+2.5, -2.5]), np.matrix([[0.8, 0.6], [0.6, 0.8]]), 50)
X5 = np.random.multivariate_normal(np.asarray([0, 0]), np.array([[1.6, 0.0], [0.0, 1.6]]), 100)

X = np.vstack((X1, X2, X3, X4, X5))
#plt.plot(X[:,0], X[:,1], ".k")

# %% [markdown]
# ### Run k-means algorithm to initialize 

# %%
#run k-means for two iterations
K = 5
N = 300

# %% [markdown]
# ### Algorithm Steps

# %%
def update_centroids(memberships, X):
    if memberships is None:
        # initialize centroids
        centroids = X[np.random.choice(range(N), K),:]
    else:
        # update centroids
        centroids = np.vstack([np.mean(X[memberships == k,], axis = 0) for k in range(K)])
    return(centroids)

def update_memberships(centroids, X):
    # calculate distances between centroids and data points
    D = spa.distance_matrix(centroids, X)
    # find the nearest centroid for each data point
    memberships = np.argmin(D, axis = 0)
    return(memberships)

# %% [markdown]
# ### Iterations

# %%
centroids = None
memberships = None
iteration = 1
while True:
    #print("Iteration#{}:".format(iteration))

    old_centroids = centroids
    centroids = update_centroids(memberships, X)
    if np.alltrue(centroids == old_centroids):
        break
    
    old_memberships = memberships
    memberships = update_memberships(centroids, X)
    if np.alltrue(memberships == old_memberships):
        break

    iteration = iteration + 1
    if iteration > 2:#just run for two iterations
        break

# %% [markdown]
# ### Take centroids as the initial values

# %%
#set centroids as the initial values for mean vectors in EM
means = centroids

#estimate initial covariance matrices using the initial means
#print(X.shape, memberships.shape)
'''covariances = [ np.matmul(np.sum(X[memberships == k, :] - means[k], axis=0), np.transpose(np.sum(X[memberships == k, :] - means[k], axis=0))) / X[memberships == k].shape[0] for k in range(K)]#covariance matrices for the five clusters '''
#covariances = [np.matmul(np.transpose(np.matrix(X[memberships == k] - means[k])), np.matrix(X[memberships == k] - means[k]) ) / (X[memberships == k].shape[0] - 1) for k in range(K)]#covariance matrices for the five clusters 

#covariances = [np.cov()]
'''covariances = [[[0, 0], [0, 0]], [[0, 0], [0, 0]], [[0, 0], [0, 0]], [[0, 0], [0, 0 ]], [[0, 0], [0, 0]]]
for k in range(K):
    for x in X:
       covariances[k] += np.matmul(np.transpose(np.matrix((X[memberships == k] - means[k]))), np.matrix((X[memberships == k] - means[k])))
    covariances[k] = covariances[k] / (X[memberships == k].shape[0] - 1)   '''
covariances = [np.cov(X[memberships == 0][:,0], X[memberships == 0][:,1]), np.cov(X[memberships == 1][:,0], X[memberships == 1][:,1]), np.cov(X[memberships == 2][:,0], X[memberships == 2][:,1]), np.cov(X[memberships == 3][:,0], X[memberships == 3][:,1]), np.cov(X[memberships == 4][:,0], X[memberships == 4][:,1])]

#estimate prior probabilities using the initial means
priorProbs = [ X[memberships == k].shape[0] / X.shape[0] for k in range(K)]
#sum(priorProbs) sums to 1 : as a check

# %% [markdown]
# ### EM algorithm

# %%
#Expectancy function of EM Algorithm
#given the mean and covariance of the cluster returns heuristic for xi
def EStep(x, means, covariances, k):
    var1 = multivariate_normal(mean = means[k], cov = covariances[k]).pdf(x) * priorProbs[k]
    var2 = [multivariate_normal(mean = means[i], cov = covariances[i]).pdf(x) * priorProbs[i] for i in range(K)]
    return var1 / np.sum(var2) 


# %%
#Maximization function of EM Algorithm
def MStep(means, covariances, priorProbs):
    updatedMeans = [0] * 5
    updatedPriorProbs = [0] * 5
    updatedCovariances = [[[0, 0], [0, 0]], [[0, 0], [0, 0]], [[0, 0], [0, 0]], [[0, 0], [0, 0]], [[0, 0], [0, 0]]]
    for k in range(K):
        hik = [EStep(x, means, covariances, k) for x in X]
        for i in range(X.shape[0]):
            hi = hik[i]
            updatedMeans[k] += hi * X[i]
            updatedPriorProbs[k] += hi
        updatedMeans[k] = updatedMeans[k] / updatedPriorProbs[k] # divided by sum of heuristic over all N 
        '''#mean update
        hik = [EStep(x, means, covariances, k) for x in X]
        updatedMeans[k] = np.sum([x * hik[i] for i,x in enumerate(X)], axis=0) / np.sum(hik)
        #update priorProb
        updatedPriorProbs[k] = np.sum(hik) / X.shape[0]
        #update covariances
        updatedCovariances[k] = np.sum([hik[i] * np.matmul((x - updatedMeans[k]), np.transpose(x - updatedMeans[k])) for i,x in enumerate(X)])  / np.sum(hik)'''
    
        for i in range(X.shape[0]):
            hi = hik[i]
            updatedCovariances[k] += hi * np.matmul(np.transpose(np.matrix((X[i] - updatedMeans[k]))), np.matrix((X[i] - updatedMeans[k]))) 
        updatedCovariances[k] = updatedCovariances[k] / updatedPriorProbs[k] # divided by sum of heuristic over all N
        

    
   
    means = np.asarray(updatedMeans)
    covariances = np.asarray(updatedCovariances)
    updatedPriorProbs = np.asarray(updatedPriorProbs) / X.shape[0]
    priorProbs = updatedPriorProbs
    '''final_means = np.asarray(updatedMeans)
    final_priorProbs = np.asarray(updatedPriorProbs)
    final_covariances = np.asarray(updatedCovariances)'''
    #print(updatedPriorProbs[0]+ updatedPriorProbs[1]+ updatedPriorProbs[2]+ updatedPriorProbs[3]+ updatedPriorProbs[4])#should sum to 1
    return means, covariances, priorProbs

# %% [markdown]
# 
# ### Run EM Algorithm for 100 iterations

# %%
#iterate 100 times
for i in range(100):#make it 100 later on!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    means, covariances, priorProbs = MStep(means, covariances, priorProbs)
    print("iteration:", (i+1)," done.")

# %% [markdown]
# ### Plot

# %%
#plot the assigned clusters
finalMemberships =  update_memberships(means, X)
k0 = X[finalMemberships == 0]
k1 = X[finalMemberships == 1]
k2 = X[finalMemberships == 2]
k3 = X[finalMemberships == 3]
k4 = X[finalMemberships == 4]

plt.figure(1)
#plot  the clustering obtained with different colors
plt.plot(k0[:,0], k0[:,1], ".y")
plt.plot(k1[:,0], k1[:,1], ".r")
plt.plot(k2[:,0], k2[:,1], ".g")
plt.plot(k3[:,0], k3[:,1], ".k")
plt.plot(k4[:,0], k4[:,1], ".b")


# %%

#plot original Gaussian densities used to generate data set with dashed lines
x1 = np.linspace(-6,6,2000)  
x2 = np.linspace(-6,6,2000)
X, Y = np.meshgrid(x1,x2) 

pos = np.empty(X.shape + (2,))                
pos[:, :, 0] = X; pos[:, :, 1] = Y   

pdf0 = multivariate_normal(mean = means[0], cov = covariances[0])#pdf for cluster 0
pdf1 = multivariate_normal(mean = means[1], cov = covariances[1])#pdf for cluster 1
pdf2 = multivariate_normal(mean = means[2], cov = covariances[2])#pdf for cluster 2
pdf3 = multivariate_normal(mean = means[3], cov = covariances[3])#pdf for cluster 3
pdf4 = multivariate_normal(mean = means[4], cov = covariances[4])#pdf for cluster 4


#plt.contour(X, Y, pdf0.pdf(pos) == 0.05, colors="k" ,alpha = 0.5, linestyles = 'dashed') #should plot if pdf(pos) == 0 but coulsn't figure it out

'''for x in X:
    for y in Y:
        if pdf0.pdf([x,y]) == 0.05:
            plt.contour(x, y, pdf0.pdf([x,y]), colors="k" ,alpha = 0.5, linestyles = 'dashed')
        else:
            continue'''

#plot Gaussian densities your EM algorithm finds with solid lines
x1 = np.linspace(-6,6,2000)  
x2 = np.linspace(-6,6,2000)
X, Y = np.meshgrid(x1,x2) 

pos = np.empty(X.shape + (2,))                
pos[:, :, 0] = X; pos[:, :, 1] = Y   

pdf0 = multivariate_normal(np.asarray([+2.5, +2.5]), np.matrix([[0.8, -0.6], [-0.6, 0.8]]))#pdf for cluster 0
pdf1 = multivariate_normal(np.asarray([-2.5, +2.5]), np.matrix([[0.8, 0.6], [0.6, 0.8]]))#pdf for cluster 1
pdf2 = multivariate_normal(np.asarray([-2.5, -2.5]), np.matrix([[0.8, -0.6], [-0.6, 0.8]]))#pdf for cluster 2
pdf3 = multivariate_normal(np.asarray([+2.5, -2.5]), np.matrix([[0.8, 0.6], [0.6, 0.8]]))#pdf for cluster 3
pdf4 = multivariate_normal(np.asarray([0, 0]), np.array([[1.6, 0.0], [0.0, 1.6]]))#pdf for cluster 4


#plt.contour(X, Y, pdf0.pdf(pos) == 0.05, colors="k" ,alpha = 0.5, linestyles = 'solid') 

plt.show()


# %%



